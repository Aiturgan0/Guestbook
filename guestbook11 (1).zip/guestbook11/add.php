<?php
error_reporting(0);
include("config.php");


$sql = "DELETE FROM `guestbook` WHERE id>3";
$sql_result = $mysqli->query ($sql) or die ('request "Could not execute SQL query" '.$sql);


$sql = "INSERT INTO ".$SETTINGS["data_table"]." SET date_time=now(), name='".$mysqli->real_escape_string($_REQUEST["name"])."', email='".$mysqli->real_escape_string($_REQUEST["email"])."', comment='".$mysqli->real_escape_string($_REQUEST["comment"])."'";
$sql_result = $mysqli->query ($sql) or die ('request "Could not execute SQL query" '.$sql);
?>
