<?php

$SETTINGS["mysql_user"]='user';
$SETTINGS["mysql_pass"]='pass';
$SETTINGS["hostname"]='localhost';
$SETTINGS["mysql_database"]='demo';
$SETTINGS["data_table"]='guestbook';



$mysqli = new mysqli($SETTINGS["hostname"], $SETTINGS["mysql_user"], $SETTINGS["mysql_pass"],$SETTINGS["mysql_database"]);

if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}
?>