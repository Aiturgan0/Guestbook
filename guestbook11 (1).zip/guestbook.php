<?php
###########################################################
/*
GuestBook Script
Copyright (C) 2012 StivaSoft ltd. All rights Reserved.


This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/gpl-3.0.html.

For further information visit:
http://www.phpjabbers.com/
info@phpjabbers.com

Version:  2.0
Released: 2020-06-15
*/
###########################################################

error_reporting(0);
include("config.php");
$sql = "SELECT * FROM ".$SETTINGS["data_table"]." ORDER BY id DESC";
$result = $mysqli->query ($sql) or die ('request "Could not execute SQL query" '.$sql);
?>

<div class="container">
    <div class="row">
        <h2>Comments |<?php echo $result->num_rows; ?>| <div class="pull-right"><a href="#" id="addacomment" class="btn btn-block btn-primary">Add a coment</a> </div></h2>
    </div>

    <hr>
    <?php
    while ($row = $result->fetch_assoc()) {

    ?>

    <div class="row comment">
        <div class="head">
            <small><strong class='user'><?php echo htmlentities(stripslashes($row["name"])); ?></strong> <?php echo $row["date_time"]; ?></small>
        </div>
        <p><?php echo htmlentities(stripslashes(nl2br($row["comment"]))); ?></p>
    </div>
    <?php } ?>
    <hr>
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <form id="GuestBookFrm" name="GuestBookFrm" action="add.php" method="post">
                <div id="contact-form" class="form-container" data-form-container>
                    <div class="row">
                        <div class="form-title">
                            <span> Add your comment </span>
                        </div>
                    </div>
                    <div class="input-container">
                        <div class="row">
					<span class="req-input">
						<span class="input-status" data-toggle="tooltip" data-placement="top" title="Please Input Your Name."> </span>
						<input type="text" name="name" data-min-length="3" placeholder="Your Name">
					</span>
                        </div>


                        <div class="row">
					<span class="req-input">
						<span class="input-status" data-toggle="tooltip" data-placement="top" title="Please Input Your Email."> </span>
						<input type="email" name="email" data-min-length="6" placeholder="Your Email">
					</span>
                        </div>



                        <div class="row">
					<span class="req-input message-box">
						<span class="input-status" data-toggle="tooltip" data-placement="top" title="Please add your Contents."> </span>
						<textarea type="textarea" name="comment" data-min-length="10" placeholder="Post Contents"> </textarea>
                        </div>
                        <div class="alert alert-info fade in alert-dismissible" id="insertedComment" style="display: none; margin-top:20px;">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                            <strong>Comment is added!<br />This is a demo installation and it will be deleted when another comment is added.</strong>
                        </div>
                        <div class="row submit-row">
                            <button type="submit" class="btn btn-block submit-form">Submit</button>
                        </div>

                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-2"></div>
    </div>

</div>