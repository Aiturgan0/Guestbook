<?php
###########################################################
/*
Rate me Script
Copyright (C) 2016 StivaSoft ltd. All rights Reserved.


This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/gpl-3.0.html.

For further information visit:
http://www.phpjabbers.com/

Version:  2.0
Released: 2020-06-19
*/
###########################################################

error_reporting(0);
include("config.php");
?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="custom.css">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
</head>

<body>

<div class="container">
    <?php
    $sql = "SELECT * FROM ".$SETTINGS["data_table"]." ORDER BY id ASC";
    $result = $mysqli->query ($sql) or die ('request "Could not execute SQL query" '.$sql);
    $counter = 0;
    while ($row = $result->fetch_assoc()) {
        $counter++;
?>
    <div class="row" id="r1" data-id="1">
        <div class="col-lg-12">
            <div class="star-rating">
                <span class="fa fa-star-o" data-rating="1"></span>
                <span class="fa fa-star-o" data-rating="2"></span>
                <span class="fa fa-star-o" data-rating="3"></span>
                <span class="fa fa-star-o" data-rating="4"></span>
                <span class="fa fa-star-o" data-rating="5"></span>
                <input type="hidden" name="whatever1" class="rating-value" value="<?php echo $row['rating']">
            </div>
        </div>
    </div>
    <?php } ?>
    <div class="row" id="r2"  data-id="2">
        <div class="col-lg-12">
            <div class="star-rating">
                <span class="fa fa-star-o" data-rating="1"></span>
                <span class="fa fa-star-o" data-rating="2"></span>
                <span class="fa fa-star-o" data-rating="3"></span>
                <span class="fa fa-star-o" data-rating="4"></span>
                <span class="fa fa-star-o" data-rating="5"></span>
                <input type="hidden" name="whatever2" class="rating-value" value="1.9">
            </div>
        </div>
    </div>

</div>
<script src="rate-me.js"></script>
<script>
    SetRatingStar($star_rating1);
    SetRatingStar($star_rating2);
</script>
</body>
</html>
